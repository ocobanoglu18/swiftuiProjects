//
//  LogInFaces_1App.swift
//  LogInFaces_1
//
//  Created by Adnan Cobanoglu on 28.04.2022.
//

import SwiftUI

@main
struct LogInFaces_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

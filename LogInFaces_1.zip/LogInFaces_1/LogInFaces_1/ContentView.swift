//
//  ContentView.swift
//  LogInFaces_1
//
//  Created by Adnan Cobanoglu on 28.04.2022.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
        ZStack {
            VStack{
            Image("PastedGraphic")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .edgesIgnoringSafeArea(.top)
               Spacer()
            }
            VStack{
            VStack{
                
            Text("LogIn UI App")
                    .bold()
                .padding(.trailing,180)
                .padding(.bottom,10)
                   
            Text("Welcome to our UI example \nscreen in an swifUI application")
                .monospacedDigit()
                .lineLimit(3)
                .padding(.trailing,100)
            }
                HStack{
                    Button {
                        
                    } label: {
                        HStack{
                        Image(systemName: "touchid")
                        Text("Smart Id")
                            .bold()
                       
                        }
                        
                    }.frame(width: 150, height: 40).background(Color.indigo).foregroundColor(Color.white)
                    .cornerRadius(10)
                
                    
                    Button {
                        
                    } label: {
                        HStack{
                        Text("SignIn")
                            .bold()
                        Image(systemName: "arrow.right")
                        }
                    }.frame(width: 150, height: 40).background(Color.indigo).foregroundColor(Color.white)
                    .cornerRadius(10)
                }.padding(.top,30)
                VStack{
                    Text("Use Social Login")
                    HStack{
                        Image("instagram").resizable().frame(width: 30, height: 30)
                        Image("twitter").resizable().frame(width: 30, height: 30)
                        Image("facebook").resizable().frame(width: 30, height: 30)
                    }
                }.padding(.top,90)
            }.padding(.top,180)
        }
       
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
